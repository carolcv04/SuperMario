#include "Koopas.h"

Koopas::Koopas(){}

Koopas::~Koopas(){}

char Koopas::getCharacter(){
    return 'k'; //koopa character
}