1. Contanct info
 - Carolina Caraballo Velez
 - 002431075
 - caraballovlez@chapman.edu
 - CPSC 350 02
 - ASSIGNMENT 2

2. Source files
 - Boss.cpp
 - Boss.h
 - Coin.cpp
 - Coin.h
 - GameObject.cpp
 - GameObject.h
 - Goomba.cpp
 - Goomba.h
 - Grid.cpp
 - Grid.h
 - Koopas.cpp
 - Koopas.h
 - Level.cpp
 - Level.h
 - logfile.txt
 - main.cpp
 - Mario.cpp
 - Mario.h
 - Mushroom.cpp
 - Mushroom.h
 - Nothing.cpp
 - Nothing.h
 - WarpPipe.cpp
 - WarpPipe.h
 - World.cpp
 - World.h

3. Limitations/Deviations
 - None. 

4. References
 - geeksforgeeks.com

5. Instructions
-  g++ *.cpp -std=c++11
- ./a.out Game.txt log.txt

Game.txt : specs of the game 
log.txt : empty file for output