#include "Coin.h"

Coin::Coin(){}

Coin::~Coin(){}

char Coin::getCharacter(){
    return 'c'; //coin character
}