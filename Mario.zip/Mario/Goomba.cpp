#include "Goombas.h"

Goombas::Goombas(){}

Goombas::~Goombas(){}

char Goombas::getCharacter(){
    return 'k'; //goomba character
}