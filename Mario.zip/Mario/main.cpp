#include "Grid.h"

using namespace std;

int main(int argc, char *argv[]){

   Grid* g = new Grid(argv[1], argv[2]); //takes in a command line input (name of the game.txt file) and output (log.txt file)
}
   