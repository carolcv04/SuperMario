#include "Mushroom.h"

Mushroom::Mushroom(){}

Mushroom::~Mushroom(){}

char Mushroom::getCharacter(){
    return 'm'; //mushroom character
}