#include "Nothing.h"

Nothing::Nothing(){}

Nothing::~Nothing(){}

char Nothing::getCharacter(){
    return 'x'; //nothing character
}